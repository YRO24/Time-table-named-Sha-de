//
//  shadeTests.swift
//  shadeTests
//
//  Created by KJSCE on 08/04/25.
//

import Testing
@testable import shade

struct shadeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
